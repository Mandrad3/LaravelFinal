<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <meta name="csrf-token" id="csrf-token" content="{{ csrf_token() }}">
    </head>
    <body>
        <select class="" name="id">
            <option value="1">Primero</option>
        </select>
        <button type="button" name="button">Mandar</button>
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
        <script src="/js/api.js">

        </script>
    </body>
</html>
